<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ═══════════════════════════════════════════════════════════
     VALUECAST CUSTOM NAVIGATION
════════════════════════════════════════════════════════════════ -->
<header class="vc-navbar" id="vc-navbar">
  <div class="vc-nav-inner vc-container">
    <a href="<?php echo esc_url( home_url('/') ); ?>" class="vc-nav-logo">
      <?php
      $logo_url = home_url('/wp-content/uploads/2026/02/logo.png');
      ?>
      <img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php bloginfo('name'); ?>">
    </a>

    <nav class="vc-nav-menu" id="vc-nav-menu">
      <?php
      /*
       * Menu priority:
       * 1. Theme location 'primary-menu' (if assigned in Appearance > Menus)
       * 2. Menu named 'Primary Menu' (exists in DB as term_id 22)
       * 3. Fallback: list published pages
       */
      $menu_rendered = false;

      // 1. Try assigned theme location
      if ( has_nav_menu( 'primary-menu' ) ) {
          wp_nav_menu( array(
              'theme_location' => 'primary-menu',
              'container'      => '',
              'menu_class'     => 'vc-menu-list',
              'depth'          => 2,
              'fallback_cb'    => false,
          ) );
          $menu_rendered = true;
      }

      // 2. Try known menu names / slugs
      if ( ! $menu_rendered ) {
          $try_menus = array( 'Primary Menu', 'primary-menu', 'VCP Menu', 'vcp-menu' );
          foreach ( $try_menus as $menu_name ) {
              if ( wp_get_nav_menu_object( $menu_name ) ) {
                  wp_nav_menu( array(
                      'menu'        => $menu_name,
                      'container'   => '',
                      'menu_class'  => 'vc-menu-list',
                      'depth'       => 2,
                      'fallback_cb' => false,
                  ) );
                  $menu_rendered = true;
                  break;
              }
          }
      }

      // 3. Ultimate fallback: list pages
      if ( ! $menu_rendered ) {
          valuecast_fallback_menu();
      }
      ?>
    </nav>

    <div class="vc-nav-actions">
      <?php
      $vc_phone    = get_theme_mod( 'vc_contact_phone', '' );
      $vc_btn_text = get_theme_mod( 'vc_header_btn_text', 'Call Now' );
      $vc_phone_clean = preg_replace( '/[^0-9+]/', '', $vc_phone );
      ?>
      <a href="tel:<?php echo esc_attr( $vc_phone_clean ); ?>" class="vc-nav-cta">
        <svg class="vc-phone-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
        <span class="vc-btn-label"><?php echo esc_html( $vc_btn_text ); ?></span>
      </a>
      <button class="vc-hamburger" id="vc-hamburger" aria-label="Toggle menu" aria-controls="vc-nav-menu" aria-expanded="false" type="button">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</header>
