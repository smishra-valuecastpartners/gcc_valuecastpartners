/**
 * contact-us.js
 * Handles tab switching on the Valuecast Contact Us page.
 * Place in: techbiz-valuecast/assets/js/contact-us.js
 */
(function ($) {
  'use strict';

  $(function () {

    var $tabs   = $('.vcc-tab');
    var $hidden = $('#vcc_tab_hidden');

    if ( ! $tabs.length ) return;

    $tabs.on('click', function () {
      var $this  = $(this);
      var tabKey = $this.data('tab');

      // Update visual state
      $tabs.removeClass('vcc-tab--active').attr('aria-selected', 'false');
      $this.addClass('vcc-tab--active').attr('aria-selected', 'true');

      // Write the selected category to the hidden form field
      if ( $hidden.length ) {
        $hidden.val( tabKey );
      }

      // Optional: update the dropdown pre-selection to match the tab
      var $select = $('#vcc_looking');
      if ( $select.length ) {
        var mapping = {
          'partnerships' : 'Partnerships',
          'talent'       : 'Careers',
          'general'      : 'Other'
        };
        if ( mapping[ tabKey ] ) {
          $select.val( mapping[ tabKey ] );
        }
      }
    });

    // ── Smooth-scroll submit feedback into view ──────────────
    var $success = $('.vcc-success-msg');
    var $error   = $('.vcc-error-msg');
    if ( $success.length ) {
      $('html, body').animate({ scrollTop: $success.offset().top - 120 }, 400);
    }
    if ( $error.length ) {
      $('html, body').animate({ scrollTop: $error.offset().top - 120 }, 400);
    }

    // ── Basic client-side validation ─────────────────────────
    $('.vcc-form').on('submit', function (e) {
      var email = $('#vcc_email').val().trim();
      var re    = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if ( ! re.test( email ) ) {
        e.preventDefault();
        $('#vcc_email').focus().css('border-color', '#c62828');
        if ( ! $('#vcc-email-err').length ) {
          $('<span id="vcc-email-err" style="color:#c62828;font-size:13px;display:block;margin-top:4px;">Please enter a valid email address.</span>')
            .insertAfter('#vcc_email');
        }
      } else {
        $('#vcc_email').css('border-color', '');
        $('#vcc-email-err').remove();
      }
    });

  });

}(jQuery));
